<?php
/**
 * The template for displaying archive pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Dexter_Organization_Theme
 */

get_header(); ?>

    <div class="main-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="news-notices-wrapper">
		<?php
		if ( have_posts() ) : ?>
			<h3 class="text-center title-wrapper"><?php
					the_archive_title();
				?></h3>
     
            <div class="row">

			<?php
			/* Start the Loop */
			while ( have_posts() ) : the_post();

				/*
				 * Include the Post-Format-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
				 */
				get_template_part( 'template-parts/content', get_post_format() );

			endwhile;

			wp_paginate('range=4&anchor=2');

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif; ?>

		</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <h3 class="text-center title-wrapper">ऐतिहासिक तस्बीरहरू</h3>
                    <div class="historical-images padding-top-15" id="historical-images">
                        <?php 
                            $args = array( 'posts_per_page' => 5,'orderby' => 'date','order'  => 'DESC', 'category' => 12 );
                            $posts = get_posts( $args );
                            foreach ( $posts as $post ) : setup_postdata( $post ); 
                        ?>
                        <div class="item">
                            <div class="panel panel-primary">
                                <div class="panel-body">
                                <a href="<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>" rel="prettyPhoto">
                                    <img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>" alt="<?php the_title(); ?>" class="img-responsive">
                                </a>
                                </div>
                                <div class="panel-footer">
                                    <h4 class="text-center"><i class="fa fa-image"></i> <?php the_title(); ?></h4>
                                </div>
                            </div>
                        </div>
                        <?php 
                            endforeach; 
                            wp_reset_postdata(); 
                        ?>
                    </div>

                    <div class="fb-page" data-href="<?php echo toz_option('Facebook' , '59493617224'); ?>" data-width="500" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="<?php echo toz_option('Facebook' , '59493617224'); ?>" class="fb-xfbml-parse-ignore"><a href="<?php echo toz_option('Facebook' , '59493617224'); ?>">Facebook</a></blockquote></div>
                </div>
        </div>
    </div>

<?php
get_footer();
