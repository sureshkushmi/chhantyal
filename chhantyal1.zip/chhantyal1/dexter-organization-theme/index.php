<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Dexter_Organization_Theme
 */

get_header(); ?>

<div class="container">
<div class="slider" id="slider">
	<?php 
		$args = array( 'posts_per_page' => 5,'orderby' => 'date','order'  => 'DESC', 'category_name' => 'slider' );
		$posts = get_posts( $args );
		foreach ( $posts as $post ) : setup_postdata( $post ); 
	?>
		<div class="item">
			<img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>" alt="<?php the_title(); ?>" class="img-responsive">
            <div class="pixel-overlay"></div>
            <h3 class="slider-content"><?php the_title(); ?></h3>
		</div>
	<?php 
		endforeach; 
		wp_reset_postdata(); 
	?>
</div>
</div>


<div class="main-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
					<div class="news-notices-wrapper" data-aos="fade-up">
                        <h3 class="title-wrapper">हाम्रो बारेमा</h3>
                        <p>
							<?php 
								sh_the_content_by_id(16);
							?>
						</p>
                    </div>
                    <div class="news-notices-wrapper">
                        <h3 class="title-wrapper">छन्त्याल गतिविधि</h3>
                        <div class="row">
                        <?php 
                            $args = array( 'posts_per_page' => 2,'orderby' => 'date','order'  => 'DESC', 'category' => 6 );
                            $posts = get_posts( $args );
                            foreach ( $posts as $post ) : setup_postdata( $post ); 
                        ?>
                        <div class="col-md-6 padding-top-15" data-aos="fade-up">
                            <a href="<?php the_permalink(); ?>">
                                <div class="news-notices-each">
                                    <img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>" alt="<?php the_title(); ?>" class="img-responsive">
                                    <h4 class="text-center"><?php the_title(); ?></h4>
                                    <p class="text-justify">
                                        <?php echo get_excerpt(355); ?>...
                                    </p>
                                </div>
                            </a>
                        </div>
                        <?php 
                            endforeach; 
                            wp_reset_postdata(); 
                        ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-4"  data-aos="fade-up">
                    <h3 class="text-center title-wrapper">ऐतिहासिक तस्बीरहरू</h3>
                    <div class="historical-images padding-top-15" id="historical-images">
                        <?php 
                            $args = array( 'posts_per_page' => 5,'orderby' => 'date','order'  => 'DESC', 'category' => 12 );
                            $posts = get_posts( $args );
                            foreach ( $posts as $post ) : setup_postdata( $post ); 
                        ?>
                        <div class="item">
                            <div class="panel panel-primary">
                                <div class="panel-body">
                                <a href="<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>" rel="prettyPhoto">
                                    <img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>" alt="<?php the_title(); ?>" class="img-responsive">
                                </a>
                                </div>
                                <div class="panel-footer">
                                    <h4 class="text-center"><i class="fa fa-image"></i> <?php the_title(); ?></h4>
                                </div>
                            </div>
                        </div>
                        <?php 
                            endforeach; 
                            wp_reset_postdata(); 
                        ?>
                    </div>

                    <div class="fb-page" data-href="<?php echo toz_option('Facebook' , '59493617224'); ?>" data-width="500" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="<?php echo toz_option('Facebook' , '59493617224'); ?>" class="fb-xfbml-parse-ignore"><a href="<?php echo toz_option('Facebook' , '59493617224'); ?>">Facebook</a></blockquote></div>
                </div>
            </div>
        </div>
    </div>


    <div class="three-cols-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="three-cols-each"  data-aos="fade-left">
                        <h3 class="text-center">जानकारी</h3>
                        <ul class="nav">
                            <?php 
                                $args = array( 'posts_per_page' => 4,'orderby' => 'date','order'  => 'DESC', 'category' => 2 );
                                $posts = get_posts( $args );
                                foreach ( $posts as $post ) : setup_postdata( $post ); 
                            ?>
                                <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                            <?php 
                                endforeach; 
                                wp_reset_postdata(); 
                            ?>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="three-cols-each"  data-aos="fade-up">
                        <h3 class="text-center">छन्त्याल लेखरचनाहरु</h3>
                        <ul class="nav">
                            <?php 
                                $args = array( 'posts_per_page' => 4,'orderby' => 'date','order'  => 'DESC', 'category' => 8 );
                                $posts = get_posts( $args );
                                foreach ( $posts as $post ) : setup_postdata( $post ); 
                            ?>
                                <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                            <?php 
                                endforeach; 
                                wp_reset_postdata(); 
                            ?>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="three-cols-each"  data-aos="fade-right">
                        <h3 class="text-center">छन्त्याल कार्यक्रमहरु</h3>
                        <ul class="nav">
                            <?php 
                                $args = array( 'posts_per_page' => 4,'orderby' => 'date','order'  => 'DESC', 'category' => 9 );
                                $posts = get_posts( $args );
                                foreach ( $posts as $post ) : setup_postdata( $post ); 
                            ?>
                                <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                            <?php 
                                endforeach; 
                                wp_reset_postdata(); 
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
	</div>

    <div class="video-wrapper">
    <div class="container">
        <h3 class="title-wrapper"><i class="fa fa-file-video-o"></i> Video</h3>
        <div id="video-slider">
        <?php 
            $args = array( 'posts_per_page' => 10,'orderby' => 'date','order'  => 'DESC', 'category' => 11 );
            $posts = get_posts( $args );
            foreach ( $posts as $post ) : setup_postdata( $post ); 
        ?>
            <div class="item">
                <a href="<?php the_permalink(); ?>">
                <img src="<?php bloginfo("url"); ?>/resize.php?src=<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>&w=290&h=155" class="img-responsive resp-image">
                <h5 class="text-center"><?php the_title(); ?></h5>
                </a>
            </div>
        <?php 
            endforeach; 
            wp_reset_postdata(); 
        ?>
        </div>
    </div>
</div>

<?php
get_footer();
