	<?php /* Template Name: Contact-Page */ get_header();?>
	
    <div class="main-wrapper">
        <div class="container">
            <div class="row">
            <div class="col-md-4">
                    <h3 class="text-center title-wrapper">सम्पर्क ठेगाना</h3>
                    <div class="padding-top-15" id="historical-images">
                        <?php dynamic_sidebar("contact-info"); ?>
                    </div>

                    <div class="fb-page" data-href="<?php echo toz_option('Facebook' , '59493617224'); ?>" data-width="500" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="<?php echo toz_option('Facebook' , '59493617224'); ?>" class="fb-xfbml-parse-ignore"><a href="<?php echo toz_option('Facebook' , '59493617224'); ?>">Facebook</a></blockquote></div>
                </div>
                <div class="col-md-8">

			<?php
			while ( have_posts() ) : the_post();

				?>
				<div class="">
					<h3 class="text-center title-wrapper"><?php
						the_title();
					?></h3>
				    <div class="news-notices-each">
				         <p class="text-justify">
				            <?php echo the_content(); ?>
				        </p>
				    </div>
				</div>
				<?php 

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					//comments_template();
				endif;

			endwhile; // End of the loop.
			?>
		</div>
		<div class="col-md-12">
			<?php dynamic_sidebar("google-map"); ?>
		</div>
        </div>
    </div>

<?php
get_footer();
