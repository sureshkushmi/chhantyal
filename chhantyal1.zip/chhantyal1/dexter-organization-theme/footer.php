<?php	


/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Dexter_Organization_Theme
 */

?>






<footer class="margin-top-15">
	<div class="container">
		<div class="row">
			<div class="col-md-3 footer-contact-info"  data-aos="fade-left">
				<h3 class="footer-title-wrapper">Contact Us</h3>
				<p>
					<?php dynamic_sidebar("footer-contact"); ?>
				</p>
			</div>
			<div class="col-md-3 footer-category" data-aos="fade-right">
				<h3 class="footer-title-wrapper footer-posts">गतिविधि</h3>
				<ul class="nav">
                    <?php 
                        $args = array( 'posts_per_page' => 3,'orderby' => 'date','order'  => 'DESC', 'category' => 6 );
                        $posts = get_posts( $args );
                        foreach ( $posts as $post ) : setup_postdata( $post ); 
                    ?>
                        <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                    <?php 
                        endforeach; 
                        wp_reset_postdata(); 
                    ?>
                </ul>
			</div>
			<div class="col-md-3 footer-quick-links"  data-aos="fade-left">
				<h3 class="footer-title-wrapper">Quick Links</h3>
				<div class="row">
					<div class="col-xs-6">
						<?php
							wp_nav_menu( array(
								'menu'              => 'footer-link-one',
								'theme_location'    => 'footer-link-one',
								'depth'             => 2,
								'container'         => 'div',
								'container_class'   => '',
								'container_id'      => 'none',
								'menu_class'        => 'nav',
								'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
								'walker'            => new wp_bootstrap_navwalker())
							);
						?>
					</div>
					<div class="col-xs-6">
						<?php
							wp_nav_menu( array(
								'menu'              => 'footer-link-two',
								'theme_location'    => 'footer-link-two',
								'depth'             => 2,
								'container'         => 'div',
								'container_class'   => '',
								'container_id'      => 'none',
								'menu_class'        => 'nav',
								'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
								'walker'            => new wp_bootstrap_navwalker())
							);
						?>
					</div>
				</div>
			</div>

		
			<div class="col-md-3 footer-social"  data-aos="fade-down">
				<h3 class="footer-title-wrapper">Find Us</h3>
				<ul class="nav">
					<li class="link"><a href="<?php echo toz_option('Facebook' , '59493617224'); ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i> Facebook</a></li>
					<li class="link"><a href="<?php echo toz_option('Twitter' , '43493625338'); ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i> Twitter</a></li>
					<li class="link"><a href="<?php echo toz_option('Google Plus' , '97493639479'); ?>" target="_blank"><i class="fa fa-google-plus" aria-hidden="true"></i> Google+</a></li>
					<li class="link"><a href="<?php echo toz_option('Youtube' , '100493651875'); ?>" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i> Youtube</a></li>
				</ul>
			</div>
		</div>
	</div>
</footer>

<div class="footer-copyright">
<div class="cotainer">
		<p class="text-center copyrights-info">Copyright &copy; 2017, Chhantyal Sangh, All Rights Reserved, Design By: <a href="http://www.ekumar.com.np" style="color:#fff">www.ekumar.com.np</a></p>
	</div>
</div>



<script src="<?php bloginfo('template_url'); ?>/theme-files/scripts/jquery-1.9.1.min.js"></script>
<script src="<?php bloginfo('template_url'); ?>/theme-files/scripts/bootstrap.min.js"></script>
<script src="<?php bloginfo('template_url'); ?>/theme-files/scripts/equal-height.js"></script>
<script src="<?php bloginfo('template_url'); ?>/theme-files/scripts/jquery.prettyPhoto.js"></script>
<script src="<?php bloginfo('template_url'); ?>/theme-files/scripts/owl.carousel.min.js"></script>
<script src="<?php bloginfo('template_url'); ?>/theme-files/scripts/breakingNews.js"></script>
<script src="<?php bloginfo('template_url'); ?>/theme-files/scripts/aos.js"></script>
<script src="<?php bloginfo('template_url'); ?>/theme-files/scripts/pace.min.js"></script>
<script type="text/javascript">
	$(document).ready(function () {
			AOS.init({
			offset: 10,
			duration: 600,
			easing: 'ease-in-sine',
			delay: 100,
		});
		$("#slider").owlCarousel({
			slideSpeed: 400,
			paginationSpeed: 400,
			singleItem: true,
			autoPlay: true,
			transitionStyle : "fade",
			addClassActive: true,
			afterMove: previousslide,
			beforeMove: nextslide
		});
		$("#historical-images").owlCarousel({
			slideSpeed: 300,
			paginationSpeed: 400,
			singleItem: true,
			autoPlay: true,
			transitionStyle : "fade",
			addClassActive: true,
			afterMove: previousslide,
			beforeMove: nextslide
		});

		$("#video-slider").owlCarousel({
			autoPlay: 3000,
			items: 4,
			itemsDesktop: [1199, 3],
			itemsDesktopSmall: [979, 3]
		});



		function previousslide() {
			jQuery(".owl-item.active .slider-content").addClass('animated fadeInUp');
		}
		function nextslide() {
				jQuery(".owl-item .slider-content").removeClass('animated fadeInUp');
		}
		$('.news-notices-each h4').matchHeight();

		$(document).ready(function() {
			$("a[rel^='prettyPhoto']").prettyPhoto();
		});

		AOS.refresh();

		$("header img").addClass("img-responsive img-center");
	});
</script>

<?php wp_footer(); ?>
 

</body>
</html>