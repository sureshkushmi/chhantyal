<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Dexter_Organization_Theme
 */

?>
<div class="col-md-6 padding-top-15">
    <a href="<?php the_permalink(); ?>">
        <div class="news-notices-each">
            <img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>" alt="<?php the_title(); ?>" class="img-responsive">
            <h4 class="text-center padding-bottom-15">
                <?php the_title(); ?><br><br>
                <small class="text-left">
                <i class="fa fa-calendar" aria-hidden="true"></i> <span>प्रकाशित मिति: </span> <?php echo get_the_date(); ?>
                </small>
            </h4>
            <?php 
            	$catArray=get_the_category(); 
            	$catId = $catArray[0]->cat_ID; 
            	if($catId=="10")
            	{
            		echo "";
            	}
            	elseif($catId=="11")
            	{
            		echo "";
            	}
            	else
            	{
            ?>
             <p class="text-justify">
                <?php echo get_excerpt(355); ?>...
            </p>
            <?php } ?>
        </div>
    </a>
</div>
