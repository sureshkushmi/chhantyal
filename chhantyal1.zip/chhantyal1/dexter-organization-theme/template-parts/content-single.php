<div class="news-notices-wrapper">
    <h2><?php the_title(); ?></h2>
    <i class="fa fa-calendar" aria-hidden="true"></i> <span>प्रकाशित मिति: </span> <?php echo get_the_date(); ?>
    <br>
    <div class="social-icons padding-top-10">
        <span class='st_sharethis_hcount' displayText='ShareThis'></span>
        <span class='st_facebook_hcount' displayText='Facebook'></span>
        <span class='st_twitter_hcount' displayText='Tweet'></span>
        <span class='st_linkedin_hcount' displayText='LinkedIn'></span>
        <span class='st_googleplus_hcount' displayText='Google +'></span>
        <span class='st_email_hcount' displayText='Email'></span>
    </div>

    <div class="row">
        <div class="col-md-12 padding-top-15">
        <?php 
            $catArray=get_the_category(); 
            $catId = $catArray[0]->cat_ID; 

            if($catId==10)
            {
                echo "";
            }
            elseif($catId==11) { ?>
                <div class="embed-responsive embed-responsive-16by9">
                    <?php echo do_shortcode("[featured-video-plus]"); ?>
                </div>
            <?php } else{?>
                <img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>" alt="<?php the_title(); ?>" class="img-responsive">
            <?php } ?>
            <p class="padding-top-15">
                <?php the_content(); ?>
            </p>
        </div>
    </div>
</div>