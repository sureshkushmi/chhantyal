<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Dexter_Organization_Theme
 */

?>

<div class="padding-top-15">
	<h3 class="text-center"><?php
		the_title();
	?></h3>
	<hr>
    <div class="news-notices-each">
        <img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>" alt="<?php the_title(); ?>" class="img-responsive">
         <p class="text-justify">
            <?php echo the_content(); ?>
        </p>
    </div>
</div>