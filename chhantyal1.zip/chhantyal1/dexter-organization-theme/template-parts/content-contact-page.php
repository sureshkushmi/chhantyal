<div class="padding-top-15">
	<h3 class="text-center"><?php
		the_title();
	?></h3>
	<hr>
    <div class="news-notices-each">
         <p class="text-justify">
            <?php echo the_content(); ?>
        </p>
    </div>
</div>