<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Dexter_Organization_Theme
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/theme-files/styles/bootstrap.min.css">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/theme-files/styles/font-awesome.min.css">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/theme-files/styles/custom-styles.css">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/theme-files/styles/owl.carousel.css">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/theme-files/styles/global-styles.css">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/theme-files/styles/prettyPhoto.css">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/theme-files/styles/owl.transitions.css">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/theme-files/styles/animate.css">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/theme-files/styles/hover-min.css">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/theme-files/styles/aos.css">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/theme-files/styles/pace.css">
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<script type="text/javascript">var switchTo5x=true;</script>
<script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
<script type="text/javascript">stLight.options({publisher: "91f09978-cc7e-4c2e-9650-a1e7e8055bba", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=440080386153926";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

    <header>
        <!-- <div class="container"> -->
            <div class="header-info">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 header-info-date">
                        <iframe scrolling="no" border="0" frameborder="0" marginwidth="0" marginheight="5" allowtransparency="true" src="http://www.ashesh.com.np/linknepali-time.php?time_only=no&amp;font_color=FFF&amp;aj_time=yes&amp;font_size=12&amp;line_brake=0&amp;api=711239g129" style="color:#000; text-align:center;" width="334" height="22"></iframe>
                    </div>
                    <div class="col-md-6 header-info-social">
                        <p class="text-right">
                            <a href="<?php echo toz_option('Facebook' , '59493617224'); ?>" target="_blank"><i class="fa fa-facebook"></i></a>
                            <a href="<?php echo toz_option('Twitter' , '43493625338'); ?>" target="_blank"><i class="fa fa-twitter"></i></a>
                        </p>
                    </div>
                </div>
            </div>
            </div>
        <!-- </div> -->
        <div class="logo-container">
        <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12">
            <p class="text-center">
                <?php dynamic_sidebar("logo-holder"); ?>
                </p>
            </div>
           
        </div>
            
        </div>
        </div>
    </header>

    <!-- <div class="container"> -->
    <nav class="navbar navbar-default navbar-static-top" style="border-radius:0px;">
    <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-ex1-collapse" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <?php
				wp_nav_menu( array(
					'menu'              => 'primary-menu',
					'theme_location'    => 'primary-menu',
					'depth'             => 2,
					'container'         => 'div',
					'container_class'   => 'collapse navbar-collapse navbar-ex1-collapse',
					'container_id'      => 'none',
					'menu_class'        => 'nav navbar-nav',
					'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
					'walker'            => new wp_bootstrap_navwalker())
				);
			?>
            </div>
    </nav>
    <!-- </div> -->

